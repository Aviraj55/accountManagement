# config file containing credentials for RDS MySQL instance
db_username = "admin"
db_password = "Aviraj55"
db_name = "account_management"
